﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Vitevic.Foundation
{
    /// <summary>
    ///     Defines the base class for all ViewModel classes in the Vitevic namespace.
    ///     It provides support to property changed notifications.
    /// </summary>
    public abstract class NotifyPropertyChangedImpl : INotifyPropertyChanged
    {
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        /// <summary>
        ///     Set the property with the specified value. If the value is not equal with the field then the field is
        ///     set, a PropertyChanged event is raised and it returns true.
        /// </summary>
        /// <typeparam name="T">Type of the property.</typeparam>
        /// <param name="field">Reference to the backing field of the property.</param>
        /// <param name="value">The new value for the property.</param>
        /// <param name="propertyName">
        ///     The property name. This optional parameter can be skipped
        ///     because the compiler is able to create it automatically.
        /// </param>
        /// <returns>True if the value has changed, false if the old and new value were equal.</returns>
        [DebuggerStepThrough]
        protected bool SetProperty<T>(ref T field, T value, string propertyName)
        {
            if( Equals(field, value) )
                return false;

            field = value;
            RaisePropertyChanged(propertyName);
            return true;
        }

        /// <summary>
        ///     Raises the <see cref="PropertyChanged" /> event.
        /// </summary>
        /// <param name="propertyName">The property name of the property that has changed.</param>
        protected void RaisePropertyChanged(string propertyName)
        {
            VerifyPropertyName(propertyName);
            OnPropertyChanged(new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        ///     Raises the <see cref="PropertyChanged" /> event.
        /// </summary>
        /// <param name="e">
        ///     The <see cref="System.ComponentModel.PropertyChangedEventArgs" /> instance containing the event data.
        /// </param>
        protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if( handler != null )
                handler(this, e);
        }

        /// <summary>
        ///     Verifies that a property name exists in this ViewModel. This method
        ///     can be called before the property is used, for instance before
        ///     calling RaisePropertyChanged. It avoids errors when a property name
        ///     is changed but some places are missed.
        ///     <para>This method is only active in DEBUG mode.</para>
        /// </summary>
        /// <param name="propertyName"></param>
        [Conditional("DEBUG")]
        [DebuggerStepThrough]
        protected void VerifyPropertyName(string propertyName)
        {
            Type myType = GetType();
            if( myType.GetProperty(propertyName) == null )
            {
                throw new ArgumentException("Property not found", propertyName);
            }
        }
    }
}