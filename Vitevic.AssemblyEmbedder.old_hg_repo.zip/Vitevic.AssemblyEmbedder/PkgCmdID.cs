﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Vitevic.AssemblyEmbedder
{
    static class PkgCmdIDList
    {
        public const uint cmdidEmbed = 0x100;


    };
}