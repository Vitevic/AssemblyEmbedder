﻿namespace Vitevic.Vsx.Service
{
    public interface IVsxService
    {
        BasePackage Package { get; }
    }
}