﻿namespace Vitevic.Vsx
{
    public interface IBaseVsxObject
    {
        BasePackage Package { get; }
    }
}